package com.dbt.excelgeneratordemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelGeneratorDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelGeneratorDemoApplication.class, args);
	}

}
