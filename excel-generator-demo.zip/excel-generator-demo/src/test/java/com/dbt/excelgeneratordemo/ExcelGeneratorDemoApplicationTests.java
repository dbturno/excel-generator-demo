package com.dbt.excelgeneratordemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelGeneratorDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
